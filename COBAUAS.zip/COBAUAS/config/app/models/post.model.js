module.exports = (mongoose) => {
    const schema = mongoose.Schema(
        {
            title: String,
            email: String,
            city: String
        },
        { timestamps: true }
    )

    schema.method("toJSON", function() {
        const {__v, _id, ...object} = this.toObject()
        object.id = _id 
        return Object
    })

    const Post = mongoose.model("posts", schema)
    return Post
}