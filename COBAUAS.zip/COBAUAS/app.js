const express = require('express')
const cors = require('cors')

const app = express()

app.use(express.json())
app.use(express.urlencoded({
    extended: true
}))


const db = require('./config/app/models/')
db.mongoose
    .connect(db.url, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
        useFindAndModify: true
    })
    .then(() => {
        console.log('Database Tersambung!')
    }).catch((err) => {
        console.log('Database Tidak Tersambung!', err)
        process.exit()
    });

app.get('/', (req, res)=> {
    res.json({
        pesan:  "Selamat Datang!"
    })
})

require('./config/app/routes/post.routes')(app)

const PORT = 8000
app.listen(PORT, () => {
    console.log('Server Berjalan pada http://localhost:8000')
})